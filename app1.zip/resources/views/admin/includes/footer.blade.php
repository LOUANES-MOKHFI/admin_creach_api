<!-- Footer opened -->
	<div class="main-footer ht-40">
		<div class="container-fluid pd-t-0-f ht-100p">
			<span>Copyright © {{date('Y')}} <a href="#">RAWDATI</a>. DEVELOPPER PAR <a href="https://www.spruko.com/">L-DEV</a> Tous droits réservés.</span>
		</div>
	</div>
<!-- Footer closed -->
