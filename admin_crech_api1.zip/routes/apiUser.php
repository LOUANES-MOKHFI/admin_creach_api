<?php

/* use App\Http\Controllers\Api\User\UserLoginController;
use Illuminate\Support\Facades\Route;

Route::post('login',[UserLoginController::class,'login']);

Route::group(['middleware' => 'auth:sanctum'],function(){
    Route::get('profile',[UserLoginController::class,'UserDetails']);
    Route::get('logout',[UserLoginController::class,'logout']);
}); */