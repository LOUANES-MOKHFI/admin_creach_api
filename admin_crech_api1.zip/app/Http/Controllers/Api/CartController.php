<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Jackiedo\Cart\Cart;
use App\Models\Product;
use App\Models\Order;
use App\Models\OrderDetail;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;

use Illuminate\Support\Str;
use DB;
class CartController extends Controller
{
    protected $cart;

    public function __construct(Cart $cart)
    {
        $this->cart = $cart->name('shopping');
    }

    public function CartContentHeader(){

        $data = [];
        $data['countProduct'] = count(Cart::name('shopping')->getItems());
        $data['totalPrice'] = Cart::name('shopping')->getSubtotal();
        return Response(['data' => $data],200);

    }
    public function content(){
        $items = $this->cart->name('shopping')->getDetails()->get('items');
        //dd($items);
        return Response(['data' => $items],200);
    }
    public function addToCart(Request $request)
    {
        

        try{
            $id = $request->id;
            $qty = $request->qty;
            $product = Product::where('id',$id)->first();
            $shoppingCart   = $this->cart->name('shopping');
            $productItem  = $shoppingCart->addItem([
                    'id'       => $product->id,
                    'title'    => $product->name,
                    'quantity' => $qty,
                    'price'    => $product->price,
            ]);

        //dd($this->cart->getDetails()->get('items')->groupBy('title'));
            $msg = "تمت اضافة الكتاب الى السلة";
            return $this->sendResponse(200,$msg);
        }catch(\Throwable $th){
            return $this->sendError($th);
        }
    }
    
    public function updateItemInCart(Request $request){
        try{
            $id = $request->id;
            $qty = $request->qty;
            $hash = $request->hash;
            $updatedItem = $this->cart->updateItem($hash, [
                'quantity' => $qty,
            ]);
        // dd($updatedItem);
            $msg = "تم التعديل على السلة";
            return $this->sendResponse(200,$msg);
        }catch(\Throwable $th){
            return $this->sendError($th);
        }
    }

    public function clearCart()
    {
        try{
            $scart = $this->cart->name('shopping');
            $scart->clearItems();
            //\Jackiedo\Cart\Facades\Cart::name('shopping')->clearItems($withEvent = true);
            //dd(\Jackiedo\Cart\Facades\Cart::name('shopping')->getItems());
            $msg = "تم تفريغ السلة";
            return $this->sendResponse(200,$msg);
        }catch(\Throwable $th){
            return $this->sendError($th);
        }
    }

    public function clearItem($hash){

        try{
            $this->cart->removeItem($hash,$withEvent=true);
            //$this->cart->removeItem($item, $withEvent = true);        
            $msg = "تم حذف المنتج من السلة";
            return $this->sendResponse(200,$msg);
        }catch(\Throwable $th){
            return $this->sendError($th);
        }
    }

    public function checkout(){

        try{
            $data = [];
            $items = $this->cart->name('shopping')->getDetails()->get('items');
            return Response(['data' => $items],200);
        }catch(\Throwable $th){
            return $this->sendError($th);
        }
    }

    public function validateCheckout(Request $request){
        
        try{
            DB::beginTransaction();
            $user = $request->user();
            
            $id = Order::create([
                'product_id' => $request->product_id,
                'vendor_id' => $product->vendor_id,
                'qty' => $request->qty,
                'name' => $request->name,
                'phone' => $request->phone,
                'email' => $request->email,
                'address' => $request->address,
                'total_order' => $request->qty * $product->price,
                'note' => $request->note,
                'user_id'  => $user->id
            ])->id;

            
            $items = $this->cart->name('shopping')->getDetails()->get('items');
            
            foreach($items as $key => $item){
                $orderDetail = OrderDetail::create([
                    'order_id' => $id,
                    'Product_id' => $item->id,
                    'qty' => $item->quantity,
                    'price' => $item->price,
                ]);
            }
            if($id && $orderDetail){
                $this->clearCart();
                //$this->sendMail($request->name,$request->email,$code);
                DB::commit();
                $msg = "تم تأكيد الطلبية";
                return $this->sendResponse(200,$msg);
            }else{
                return $this->sendError("هناك خطأ في السيرفر");
            }
            
        }catch(\Exception $e){
            return $this->sendError($th);
           // DB::rollback();
        }
        
        
    }
    function sendMail($client_name,$client_email,$code_order){
        //$to_email = 'louanes.mokhfi@gmail.com';
        $to_email = 'louanes.mokhfi@gmail.com';
        $data = array('name'=>$client_name, "header" => "لديك طلبية جديدة :",
        "Email" => "إيمايل العميل :".$client_email,
        "Name" => "اسم العميل :".$client_name,
        "codeOrder" => "كود الطلبية  :".$code_order);
        Mail::send('emails.mail', $data, function($message) use ($client_name, $to_email) {
        $message->to($to_email, $client_name)
        ->subject('الأكادمية للنشر و الترجمة');
        $message->from('library@g-clinique.com','الأكادمية للنشر و الترجمة');
        });
        
    }

    public function sendError($error, $errorMessages = [], $code = 204)
    {
    	$response = [
            'success' => false,
            'status'    => $code,
            'message' => $error,
        ];
        if(!empty($errorMessages)){
            $response['data'] = $errorMessages;
        }
        return response()->json($response);
    }
    public function sendResponse($result, $message)
    {
    	$response = [
            'success' => true,
            'status'    => $result,
            'message' => $message,
        ];
        return response()->json($response, 200);
    }
}
