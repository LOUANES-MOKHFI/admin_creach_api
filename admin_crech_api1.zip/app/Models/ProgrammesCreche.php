<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProgrammesCreche extends Model
{
    use HasFactory;
    protected $table = 'programmes_creches';
    protected $guarded = [];


}
