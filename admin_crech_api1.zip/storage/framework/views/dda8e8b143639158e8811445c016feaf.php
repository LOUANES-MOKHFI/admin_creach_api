<?php $__env->startSection('title',' تعديل قسم الوثائق'); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="breadcrumb-header justify-content-between">
    <div class="my-auto">
        <div class="d-flex">
            <h4 class="content-title mb-0 my-auto">الرئيسية</h4><span class="text-muted mt-1 tx-13 mr-2 mb-0">/ تعديل قسم الوثائق</span>
        </div>
    </div>

</div>
<div class="row">
    <div class="col-lg-12 col-md-12">
        <div class="card">
            <div class="card-body">
                <?php echo $__env->make('admin.includes.alerts.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <form class="form" action="<?php echo e(route('admin.dossiers.update',$dossier->uuid)); ?>"
                      method="POST"
                      enctype='multipart/form-data'>
                    <?php echo csrf_field(); ?>
                    <div class="form-body">

                        <h4 class="form-section"><i class="ft-home"></i>معلومات القسم </h4>

                        <div class="row">
                        <div class="col-md-4">
                                <div class="form-group">
                                    <label for="projectinput1">  نوع القسم </label>
                                    <select name="type" id="type_class"  class="form-control">
                                        <option value="">-- اختر نوع القسم --</option>
                                        <option value="1"> قسم فرعي </option>
                                        <option value="2">  صور </option>
                                    </select>
                                    <?php $__errorArgs = ["name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"> <?php echo e($message); ?>  </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="projectinput1">  اسم القسم </label>
                                    <input type="text" value="<?php echo e($dossier->name); ?>" id="name"
                                           class="form-control"
                                           placeholder="  "
                                           name="name">
                                    <?php $__errorArgs = ["name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"> <?php echo e($message); ?>  </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4" id="dossier" <?php if($dossier->parent_id == null ): ?> style="display:none" <?php endif; ?>>
                                <div class="form-group">
                                    <label for="projectinput1" > القسم الأساسي </label>
                                    <select name="parent_id" id="parent_id"  class="form-control">
                                        <option value="">-- اختر القسم --</option>
                                        <?php if(isset($dossiers)): ?>
                                        <?php $__currentLoopData = $dossiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dossierr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($dossierr->id); ?> <?php echo e($dossierr->id == $dossier->parent_id ? 'selected' : ''); ?>"><?php echo e($dossierr->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                    <?php $__errorArgs = ["name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"> <?php echo e($message); ?>  </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-12" id="images" <?php if($dossier->parent_id != null): ?> style="display:none" <?php endif; ?>>
                                <div class="form-group">
                                    <label for="projectinput1"> الصور </label>
                                    <input type="file" multiple id="images"
                                           class="form-control"
                                           placeholder=" "
                                           name="images[]">
                                    <?php $__errorArgs = ["images"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"> <?php echo e($message); ?>  </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <?php if(isset($dossier->files)): ?>
                            <div class="col-lg-12 col-xs-12">
                                <div class="row">
                                    <?php $__currentLoopData = $dossier->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3">
                                        <img src="<?php echo e(asset('files/dossiers/'.$image->name)); ?>"  alt="">
                                        <a href="<?php echo e(route('admin.dossiers.deleteFile',$image->uuid)); ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> </a>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>

                    </div>


                    <div class="form-actions">
                    <button type="button" class="btn btn-warning mr-1"
                                onclick="history.back();">
                            <i class="ft-x"></i> عودة
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <i class="la la-check-square-o"></i> حفظ
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $('#type_class').on('change',function(){
        if(this.value == 1){
            $('#images').css('display','none');
            $('#dossier').css('display','block');
        }else{
            $('#dossier').css('display','none');
            $('#images').css('display','block');
        }
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\louanes.mokhefi\Desktop\pr\admin_crech_api\resources\views/admin/dossiers/edit.blade.php ENDPATH**/ ?>