<?php if(session()->has('success')): ?>
			<div class="alert alert-success text-center" id="msg">
			<?php echo e(session()->get('success')); ?>

			</div>
<?php elseif(session()->has('error')): ?>
			<div class="alert alert-danger text-center" id="msg">
			<?php echo e(session()->get('error')); ?>

			</div>
<?php endif; ?>


<?php /**PATH C:\Users\louanes.mokhefi\Desktop\pr\admin_crech_api\resources\views/admin/includes/alerts/alerts.blade.php ENDPATH**/ ?>